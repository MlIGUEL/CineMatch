import tkinter as tk
from interface import CineMatchApp

if __name__ == "__main__":
    root = tk.Tk()
    app = CineMatchApp(root)
    root.mainloop()
